//
//  DreamobiNative.h
//  DreamobiDemo1.6
//
//  Created by Dreamobi on 15/1/26.
//  Copyright (c) 2015年 Dreamobi. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface DreamobiNative : NSObject


@property (nonatomic,copy)NSString *title;
@property (nonatomic,copy)NSString *description;
@property (nonatomic,copy)NSString *icon_url;
@property (nonatomic,copy)NSString *banner_url;
@property (nonatomic,copy)NSString *click_url;
@property (nonatomic,copy)NSString *cta_text;


@end

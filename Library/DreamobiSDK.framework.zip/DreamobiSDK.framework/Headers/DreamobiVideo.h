//
//  DreamobiVideo.h
//  DreamobiDemo1.6
//
//  Created by Dreamobi on 15/1/26.
//  Copyright (c) 2015年 Dreamobi. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface DreamobiVideo : NSObject

@property (nonatomic,copy)NSString *description;
@property (nonatomic,copy)NSString *title;
@property (nonatomic,copy)NSString *thumb_url;

@end
